def multiply(x,y): 
    return x * y 

numbers = [2,6,3,8,5,4] 
print(reduce(multiply, numbers))

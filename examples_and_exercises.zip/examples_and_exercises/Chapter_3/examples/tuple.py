t = (4, 5, 6)
print t[1] 
for e in t:
    print(e+1) 
